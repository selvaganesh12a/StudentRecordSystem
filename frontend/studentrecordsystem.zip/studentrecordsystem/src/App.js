import "./App.css";
import { useState, useEffect, use } from "react";
import StudentList from "./components/StudentList";
import StudentForm from "./components/StudentForm";
import Navbar from "./components/Navbar";
import { Routes, Route, Link, useNavigate } from "react-router-dom";
import {
  addStudent,
  getAllstudents,
  deleteStudent,
  updateStudent,
} from "./services/studentService";

function App() {
  const [students, setStudents] = useState([]);
  const [editingStudent, setEditingStudent] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    getAllstudents()
      .then((response) => {
        setStudents(response.data);
        console.log(response.data);
      })
      .catch((error) => {
        console.log("Error fetching students:", error);
      });
  }, []);

  function handleAddStudent(newStudent) {
    addStudent(newStudent)
      .then(() => getAllstudents())
      .then((response) => {
        console.log("response" + response.data);
        setStudents(response.data);
      }).catch((error) => console.error("Add failed:", error));
      navigate("/studentlist");
  }

  function handleUpdateStudent(updatedStudent) {
    updateStudent(updatedStudent.id, updatedStudent)
      .then(() => getAllstudents())
      .then((response) => setStudents(response.data))
      .catch((error) => console.error("Update failed:", error));
    setEditingStudent(null);
  }

  function handleDeleteStudent(studentId) {
    deleteStudent(studentId)
      .then(() => getAllstudents())
      .then((response) => {
        setStudents(response.data);
      });
  }

  function handleCancel() {
    setEditingStudent(null);
  }

  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route
          path="/"
          element={<h1>Welcome to Student Management System</h1>}
        />
        <Route
          path="/studentlist"
          element={
            <StudentList
              students={students}
              handleDeleteStudent={handleDeleteStudent}
            />
          }
        />
        <Route
          path="/addstudent"
          element={
            <StudentForm
              mode="add"
              setStudents={setStudents}
              handleAddStudent={handleAddStudent}
              handleCancel={handleCancel}
            />
          }
        />
        <Route
          path="/editstudent/:id"
          element={
            <StudentForm
              mode="edit"
              handleUpdateStudent={handleUpdateStudent}
              students={students}
              handleCancel={handleCancel}
            />
          }
        />
      </Routes>
    </div>
  );
}

export default App;
